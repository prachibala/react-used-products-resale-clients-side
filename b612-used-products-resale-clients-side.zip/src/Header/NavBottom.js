// import React from "react";
// import { Link } from "react-router-dom";

// const NavBottom = () => {
//     return (
//         <div className="navbar bg-neutral invisible lg:visible text-neutral-content">
//             <div className=" w-2/4   mx-auto flex justify-around   ">
//                 <Link className="btn btn-ghost font-normal  text-white">
//                     Home
//                 </Link>
//                 <Link className="btn btn-ghost font-normal  text-white">
//                     About
//                 </Link>
//                 <Link className="btn btn-ghost font-normal  text-white">
//                     Home Furniture
//                 </Link>
//                 <Link className="btn btn-ghost font-normal  text-white">
//                     Office Furniture
//                 </Link>
//                 <Link className="btn btn-ghost font-normal  text-white">
//                     Hospital Furniture
//                 </Link>
//             </div>
//         </div>
//     );
// };

// export default NavBottom;
