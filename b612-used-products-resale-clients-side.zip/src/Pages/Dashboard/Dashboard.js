import React from "react";

const Dashboard = () => {
    return <div className="w-10/12 mx-auto">iam a dashboard</div>;
};

export default Dashboard;
